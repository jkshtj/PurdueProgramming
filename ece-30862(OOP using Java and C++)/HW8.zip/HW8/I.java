interface I {

   //public I( ) { }; // A- interfaces do not have constructors

   int s = 0;
   int i = 1;

   void foo(short s); 

   void foo(int i); 

}
