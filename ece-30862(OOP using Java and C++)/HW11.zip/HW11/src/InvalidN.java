public class InvalidN extends Exception{

	private static final long serialVersionUID = 1L;
	
	public InvalidN(String s){
		super(s);
	}
}

