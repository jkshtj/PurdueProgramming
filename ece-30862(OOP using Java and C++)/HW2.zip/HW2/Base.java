public class Base {

   public Base( ) { }

   // add necessary function(s) here 
   public void f1()
   {
	   System.out.println("Base f1");
   }
   
   public void f2()
   {
	   System.out.println("Base f2");
   }

}

