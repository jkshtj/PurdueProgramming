public class Derived extends Base {

   public Derived( ) { }

   // add necessary function(s) here.
   public void f2()
   {
	   System.out.println("Derived f2");
   }

}

